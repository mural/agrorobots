﻿Imports System.Data.SqlClient
Imports Business
Imports DTO

Public Class Site
    Inherits System.Web.UI.MasterPage


    Dim login As New Business.Login
    Dim usuario As Usuario

    Dim menuItem As MenuItem

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        usuario = Session.Item("user")
        Elegir_Perfil(usuario)
    End Sub

    Public Sub Elegir_Perfil(ByRef usuario As Usuario)
        If usuario Is Nothing Then
            Response.Redirect("/Pantalla_Login.aspx")
        Else
            If usuario.Admin = True Then
                menuItem = NavigationMenu.FindItem("MenuAdvance")
                If menuItem IsNot Nothing Then
                    NavigationMenu.Items.Remove(menuItem)
                End If
            Else
                menuItem = NavigationMenu.FindItem("MenuAdmin")
                If menuItem IsNot Nothing Then
                    NavigationMenu.Items.Remove(menuItem)
                End If
            End If
        End If
    End Sub

    Public Sub Logout()
        FormsAuthentication.SignOut()
        Bitacora_Business.Logear("Logout", "Logout exitoso", HttpContext.Current.User.Identity.Name)
        Response.Redirect("/Pantalla_Login.aspx")
    End Sub

    Protected Sub NavigationMenu_MenuItemClick(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.MenuEventArgs) Handles NavigationMenu.MenuItemClick
        Select Case e.Item.Value
            Case "Home"
                Response.Redirect("Pantalla_Principal.aspx")
            Case "Bitacora"
                Response.Redirect("Bitacora.aspx")
            Case "Backup"
                Response.Redirect("Backup.aspx")
            Case "Compras"
                Response.Redirect("Carrito.aspx")
            Case "Logout"
                Logout()
            Case "Contactenos"
                Response.Redirect("Contactenos.aspx")
            Case "Catalogo"
                Response.Redirect("Catalogo.aspx")
            Case "QuienesSomos"
                Response.Redirect("Quienes.aspx")

        End Select
    End Sub
End Class