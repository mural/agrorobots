﻿
Class EjemploException
    Inherits Exception

End Class
