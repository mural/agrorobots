﻿Public Class Simbolos

    Public Shared FlechaDerecha = "&#x27a4"

End Class
