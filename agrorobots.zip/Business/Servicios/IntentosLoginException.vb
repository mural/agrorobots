﻿Public Class IntentosLoginException
    Inherits Exception
End Class
