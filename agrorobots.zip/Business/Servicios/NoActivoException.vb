﻿Public Class NoActivoException
    Inherits Exception
End Class
