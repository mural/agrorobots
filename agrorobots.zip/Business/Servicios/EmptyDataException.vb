﻿
Class EmptyDataException
    Inherits Exception

End Class
