﻿Public Class SinPermisos
    Inherits PaginaGenerica

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Overrides Sub TraducirComponentesDinamicos()

    End Sub
End Class